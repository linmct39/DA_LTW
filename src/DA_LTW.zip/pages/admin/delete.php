<?php
session_start();
require_once("../../config/database.php");
$database = new Database();
$db = $database->getConnection();

// BẢO MẬT: Kiểm tra đăng nhập VÀ quyền Admin
// Nếu chưa đăng nhập HOẶC quyền không phải là 'admin' -> Đá về trang login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { 
    header("Location: ../login.php"); 
    exit; 
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Tùy chọn: Xóa ảnh trong thư mục (nếu cần)
    // $stmt = $db->prepare("SELECT image FROM products WHERE id = ?");
    // ... logic xóa file ảnh ...

    // Xóa trong database
    $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt->execute([$id])) {
        // Xóa thành công
        header("Location: index.php");
    } else {
        echo "Lỗi: Không thể xóa sản phẩm.";
    }
} else {
    header("Location: index.php");
}
?>