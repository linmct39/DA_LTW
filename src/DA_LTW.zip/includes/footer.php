<!-- FOOTER -->
        <footer class="footer">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Về Organic Shop</h3>
                    <p>Chuyên cung cấp thực phẩm hữu cơ chất lượng cao, an toàn cho sức khỏe người tiêu dùng.</p>
                </div>
                
                <div class="footer-section">
                    <h3>Liên Hệ</h3>
                    <p>0123.456.789</p>
                    <p>truclinh@holibolifarm.vn</p>
                    <p>180, Cao Lỗ, TP.HCM</p>
                </div>
                
                <div class="footer-section">
                    <h3>Chính Sách</h3>
                    <p><a href="#">Chính sách bảo mật</a></p>
                    <p><a href="#">Điều khoản sử dụng</a></p>
                    <p><a href="#">Chính sách giao hàng</a></p>
                    <p><a href="#">Chính sách đổi trả</a></p>
                </div>
                
                <div class="footer-section">
                    <h3>Kết Nối Với Chúng Tôi</h3>
                    <p><a href="#">Facebook</a></p>
                    <p><a href="#">Instagram</a></p>
                    <p><a href="#"> Zalo</a></p>
                    <p><a href="#">TikTok</a></p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 Holicoli Shop. All rights reserved. | Thực phẩm hữu cơ chất lượng cao</p>
            </div>
        </footer>
    </div>