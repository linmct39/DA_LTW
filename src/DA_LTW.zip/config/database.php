<?php
    class Database{
        private $host ="localhost";
        private $dbname ="organic_shop";
        private $username="root";
        private $password="";
        public $conn;

        public function getConnection(){
            $this-> conn =null;
            try{
                $this->conn = new PDO(
                    "mysql:host=".$this->host.";dbname=".$this->dbname,
                    $this->username,
                    $this->password   
                );
            }catch(PDOException $err){
                echo "Kết nối thất bại ".$err->getMessage();
            }
            return $this->conn;
        }

    } 
    // cái này phải thực hiên thêm hai thằng khởi tạo khoogn thôi nó khoogn nhận diện dược 
    $database = new Database();
    $db = $database->getConnection();


?>